import base64
import logging

# Lamba Handler
def _lambda_handler(event, context):
    logger.debug('Event: %s', event)

# Global lambda handler - catches all exceptions to avoid dead letter in the DynamoDB Stream
def lambda_handler(event, context):
    try:
        return _lambda_handler(event, context)
    except Exception:
        logger.error(traceback.format_exc())